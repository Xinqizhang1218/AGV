"""Nodka NKLC software-switch control through the small native ABI bridge."""
from __future__ import annotations

import argparse
import ctypes
import logging
import math
from pathlib import Path
import sys
import threading
import time

from agv_vision.core.exceptions import SourceError
from agv_vision.utils.timing import log_step


class LightResult(ctypes.Structure):
    _fields_ = [("sdk_return", ctypes.c_int32)] + [
        (name, ctypes.c_uint32) for name in (
            "received", "error", "error_id", "port", "device", "channel",
            "mode", "brightness", "on",
        )
    ]


class LightStatusError(SourceError):
    """Carry a status snapshot taken while holding the capture lock."""

    def __init__(self, message: str, held: bool, state: str = 'unknown'):
        super().__init__(message)
        self.status = {'state': state, 'held': held}


class NodkaLight:
    """One controller per process; all commands serialized and read back.

    SDK synchronous calls own the serial timeout. No blind retry on failure.
    A successful readback confirms controller parameters, not physical light.
    """
    _owner_lock = threading.Lock()

    def __init__(self, library_path: str, config_path: str, port: int,
                 channel_mask: int, brightness: int = 50):
        if isinstance(port, bool) or not isinstance(port, int) or not 0 <= port <= 65535:
            raise ValueError("port must be an explicit Linux SDK port number (0..65535)")
        if channel_mask not in (1, 2, 4, 8):
            raise ValueError("channel_mask must select one channel: 1, 2, 4, or 8")
        if isinstance(brightness, bool) or not isinstance(brightness, int) or not 0 <= brightness <= 100:
            raise ValueError("brightness must be an integer in 0..100")
        self.library_path = Path(library_path).resolve()
        self.config_path = Path(config_path).resolve()
        self.port = port
        self.channel_mask = channel_mask
        self.brightness = brightness
        self._library = None
        self._initialized = False
        self._port_attempted = False
        self._device_verified = False
        self._owns_library = False
        self._lock = threading.RLock()

    def _load_library(self):
        if sys.platform != "linux":
            raise SourceError("NKLC Linux SDK requires Linux; Windows cannot load this .so")
        for path in (self.library_path, self.config_path):
            if not path.is_file():
                raise SourceError(f"NKLC file missing: {path}")
        library = ctypes.CDLL(str(self.library_path))
        result_pointer = ctypes.POINTER(LightResult)
        signatures = {
            "agv_light_init": ([ctypes.c_char_p], ctypes.c_int),
            "agv_light_deinit": ([], None),
            "agv_light_open": ([ctypes.c_uint16, result_pointer], None),
            "agv_light_close": ([ctypes.c_uint16, result_pointer], None),
            "agv_light_set": ([ctypes.c_uint32, ctypes.c_uint8, ctypes.c_uint8,
                               ctypes.c_uint8, result_pointer], None),
            "agv_light_get": ([ctypes.c_uint32, ctypes.c_uint8, result_pointer], None),
        }
        for name, (arguments, result) in signatures.items():
            function = getattr(library, name)
            function.argtypes = arguments
            function.restype = result
        return library

    def _command(self, name: str, *arguments: int) -> LightResult:
        result = LightResult()
        getattr(self._library, name)(*arguments, ctypes.byref(result))
        if result.sdk_return < 0 or not result.received or result.error or result.error_id:
            raise SourceError(
                f"{name} failed: return={result.sdk_return}, callback={result.received}, "
                f"error={result.error}, error_id={result.error_id}; device state unconfirmed"
            )
        return result

    def open(self) -> None:
        with self._lock:
            if self._initialized:
                return
            if not self._owner_lock.acquire(blocking=False):
                raise SourceError("Only one NodkaLight instance may own NKLC in this process")
            self._owns_library = True
            try:
                self._library = self._load_library()
                code = self._library.agv_light_init(str(self.config_path).encode())
                if code != 0:
                    raise SourceError(f"NKLC initialization failed: {code}")
                self._initialized = True
                self._port_attempted = True
                result = self._command("agv_light_open", self.port)
                # NP-6133-MVS / SDK 5.0.4 reports port=2, devId=0 for
                # OpenDevice(3), while device 1 correctly reads CH1. These
                # open callback fields are diagnostic, not device identity.
                logging.getLogger(__name__).info(
                    "NKLC opened requested_port=%s returned_port=%s returned_device=%s",
                    self.port, result.port, result.device,
                )
                state = self._command("agv_light_get", 1, self.channel_mask)
                if (state.channel != self.channel_mask or state.mode not in (0, 1, 2, 3)
                        or state.brightness > 100 or state.on not in (0, 1)):
                    raise SourceError(
                        f"NKLC initial channel readback invalid: expected_channel={self.channel_mask}, "
                        f"channel={state.channel}, mode={state.mode}, "
                        f"brightness={state.brightness}, on={state.on}"
                    )
                self._device_verified = True
                self.turn_off()
            except BaseException:
                try:
                    self.close()
                except Exception:
                    logging.getLogger(__name__).exception("NKLC startup cleanup failed")
                raise

    def _set_switch(self, is_on: bool) -> None:
        with self._lock:
            if not self._initialized or not self._device_verified:
                raise SourceError("NKLC controller is not open")
            result = self._command("agv_light_set", 1, self.channel_mask,
                                   self.brightness, int(is_on))
            if result.channel != self.channel_mask:
                raise SourceError("NKLC set callback channel mismatch")
            state = self._command("agv_light_get", 1, self.channel_mask)
            if (state.channel, state.mode, state.brightness, state.on) != (
                    self.channel_mask, 0, self.brightness, int(is_on)):
                raise SourceError("NKLC readback mismatch; light state unconfirmed")

    def turn_on(self) -> None:
        self._set_switch(True)

    def read_state(self) -> str:
        """Read the controller without changing its output."""
        with self._lock:
            if not self._initialized or not self._device_verified:
                raise SourceError("NKLC controller is not open")
            state = self._command("agv_light_get", 1, self.channel_mask)
            if (state.channel != self.channel_mask or state.mode != 0
                    or state.brightness > 100 or state.on not in (0, 1)):
                raise SourceError("NKLC status readback invalid")
            return 'on' if state.on else 'off'

    def turn_off(self) -> None:
        self._set_switch(False)

    def close(self) -> None:
        with self._lock:
            errors = []
            try:
                if self._initialized and self._port_attempted:
                    actions = [lambda: self._command("agv_light_close", self.port)]
                    if self._device_verified:
                        actions.insert(0, self.turn_off)
                    for action in actions:
                        try:
                            action()
                        except Exception as exc:
                            errors.append(str(exc))
                if self._initialized:
                    # Header declares int; older manual declares void. Do not
                    # interpret this value as a portable success indicator.
                    self._library.agv_light_deinit()
            finally:
                self._initialized = False
                self._port_attempted = False
                self._device_verified = False
                if self._owns_library:
                    self._owns_library = False
                    self._owner_lock.release()
            if errors:
                raise SourceError("NKLC cleanup failed: " + "; ".join(errors))


class IlluminatedFrameSource:
    """Serialize light control and exposure; retain light only while held."""
    def __init__(self, source, light: NodkaLight, settle_ms: int):
        self.source = source
        self.light = light
        self.settle_ms = settle_ms
        self._lock = threading.RLock()
        self._faulted = False
        self._held = False
        self._is_open = False

    def open(self):
        with self._lock:
            if self._is_open:
                if self._faulted:
                    raise SourceError("Light capture faulted; close before reopening")
                return
            self.light.open()
            try:
                self.source.open()
                self._faulted = False
                self._held = False
                self._is_open = True
                logging.getLogger(__name__).info(
                    "光源拍照就绪 port=%s channel_mask=0x%02X brightness=%s settle_ms=%s",
                    self.light.port, self.light.channel_mask, self.light.brightness, self.settle_ms,
                )
            except BaseException:
                try:
                    self.light.close()
                except Exception:
                    logging.getLogger(__name__).exception("NKLC camera-start cleanup failed")
                raise

    def control_light(self, action: str) -> None:
        if action not in ('on', 'off'):
            raise ValueError('data.action 仅支持 on 或 off')
        with self._lock:
            if not self._is_open:
                raise SourceError('光源未连接')
            if action == 'on' and self._faulted:
                raise SourceError('光源采集故障，请检查硬件并关闭后重新打开采集源')
            if action == 'off':
                self._held = False
                try:
                    self.light.turn_off()
                except BaseException:
                    self._faulted = True
                    raise
                return
            try:
                self.light.turn_on()
                time.sleep(self.settle_ms / 1000.0)
                self._held = True
            except BaseException:
                self._faulted = True
                self._held = False
                try:
                    self.light.turn_off()
                except Exception:
                    logging.getLogger(__name__).exception('NKLC cleanup failed after on')
                raise

    def get_light_status(self) -> dict:
        with self._lock:
            try:
                if not self._is_open:
                    raise SourceError('光源未连接')
                state = self.light.read_state()
            except Exception as exc:
                self._faulted = True
                raise LightStatusError(str(exc), self._held) from exc
            if self._held and state != 'on':
                self._faulted = True
            if self._faulted:
                raise LightStatusError('光源采集故障未恢复', self._held, state)
            return {'state': state, 'held': self._held}

    def grab(self):
        logger = logging.getLogger(__name__)
        with self._lock:
            if self._faulted:
                raise SourceError("Light capture faulted; close and reopen after checking hardware")
            try:
                if self._held:
                    with log_step(logger, 'light_check_held'):
                        if self.light.read_state() != 'on':
                            raise SourceError('常亮保持期间光源未开启')
                else:
                    with log_step(logger, 'light_turn_on'):
                        self.light.turn_on()
                    logger.info("光源开灯读回确认，等待稳定后触发拍照 settle_ms=%s", self.settle_ms)
                    with log_step(logger, 'light_settle'):
                        time.sleep(self.settle_ms / 1000.0)
                with log_step(logger, 'camera_grab'):
                    frame = self.source.grab()
            except BaseException:
                self._faulted = True
                self._held = False
                try:
                    with log_step(logger, 'light_turn_off_after_error'):
                        self.light.turn_off()
                except Exception:
                    logging.getLogger(__name__).exception("NKLC off failed after capture failure")
                raise
            if self._held:
                logger.info('图像已获取，光源保持常亮')
                return frame
            try:
                with log_step(logger, 'light_turn_off'):
                    self.light.turn_off()  # Off failure must not be reported as success.
                logging.getLogger(__name__).info("图像已获取，光源关灯读回确认")
            except BaseException:
                self._faulted = True
                raise
            return frame

    def close(self):
        with self._lock:
            self._held = False
            self._is_open = False
            try:
                self.light.close()
            finally:
                self.source.close()


def main() -> None:
    parser = argparse.ArgumentParser(description="NKLC: turn on, wait, then turn off (Linux)")
    parser.add_argument("--library", required=True, help="libagv_nodka_light.so path")
    parser.add_argument("--config", required=True, help="model-specific nkio_config.ini")
    parser.add_argument("--port", type=int, required=True, help="actual Linux SDK port number")
    parser.add_argument("--channel-mask", type=lambda text: int(text, 0), required=True)
    parser.add_argument("--brightness", type=int, default=50)
    parser.add_argument("--seconds", type=float, default=3)
    args = parser.parse_args()
    if not math.isfinite(args.seconds) or not 0 < args.seconds <= 3600:
        parser.error("--seconds must be finite and in (0, 3600]")
    light = NodkaLight(args.library, args.config, args.port, args.channel_mask, args.brightness)
    try:
        light.open()
        light.turn_on()
        print("Light ON command/readback confirmed", flush=True)
        time.sleep(args.seconds)
    finally:
        light.close()
    print("Light OFF command/readback confirmed", flush=True)


if __name__ == "__main__":
    main()
